Drop supplementary background textures/images here (see README).
