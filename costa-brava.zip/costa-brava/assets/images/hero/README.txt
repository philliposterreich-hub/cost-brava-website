Drop your own hero photography here (see README).
