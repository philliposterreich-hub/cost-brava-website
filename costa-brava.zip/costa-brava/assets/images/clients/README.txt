Drop clients-page photography here (see README).
