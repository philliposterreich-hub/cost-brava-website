Fonts are loaded via Google Fonts CDN — see README for self-hosting instructions.
